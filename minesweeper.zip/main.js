class Minesweeper {
  constructor(width = 8, height = 8, mines = 10) {
    this.width = width;
    this.height = height;
    this.mines = mines;
    this.board = [];
    this.gameOver = false;
    this.revealed = 0;
    this.init();
  }

  init() {
    // Create empty board
    this.board = Array(this.height).fill().map(() =>
      Array(this.width).fill().map(() => ({
        isMine: false,
        revealed: false,
        flagged: false,
        neighborMines: 0
      }))
    );

    // Place mines
    let minesPlaced = 0;
    while (minesPlaced < this.mines) {
      const x = Math.floor(Math.random() * this.width);
      const y = Math.floor(Math.random() * this.height);
      
      if (!this.board[y][x].isMine) {
        this.board[y][x].isMine = true;
        minesPlaced++;
      }
    }

    // Calculate neighbor mines
    for (let y = 0; y < this.height; y++) {
      for (let x = 0; x < this.width; x++) {
        if (!this.board[y][x].isMine) {
          this.board[y][x].neighborMines = this.countNeighborMines(x, y);
        }
      }
    }
  }

  countNeighborMines(x, y) {
    let count = 0;
    for (let dy = -1; dy <= 1; dy++) {
      for (let dx = -1; dx <= 1; dx++) {
        const ny = y + dy;
        const nx = x + dx;
        if (ny >= 0 && ny < this.height && nx >= 0 && nx < this.width) {
          if (this.board[ny][nx].isMine) count++;
        }
      }
    }
    return count;
  }

  reveal(x, y) {
    if (this.gameOver || this.board[y][x].revealed || this.board[y][x].flagged) return;

    const cell = this.board[y][x];
    cell.revealed = true;
    this.revealed++;

    if (cell.isMine) {
      this.gameOver = true;
      this.revealAll();
      return false;
    }

    if (cell.neighborMines === 0) {
      for (let dy = -1; dy <= 1; dy++) {
        for (let dx = -1; dx <= 1; dx++) {
          const ny = y + dy;
          const nx = x + dx;
          if (ny >= 0 && ny < this.height && nx >= 0 && nx < this.width) {
            if (!this.board[ny][nx].revealed) this.reveal(nx, ny);
          }
        }
      }
    }

    if (this.revealed === this.width * this.height - this.mines) {
      this.gameOver = true;
      return true;
    }

    return null;
  }

  revealAll() {
    for (let y = 0; y < this.height; y++) {
      for (let x = 0; x < this.width; x++) {
        this.board[y][x].revealed = true;
      }
    }
  }

  toggleFlag(x, y) {
    if (!this.gameOver && !this.board[y][x].revealed) {
      this.board[y][x].flagged = !this.board[y][x].flagged;
    }
  }
}

// Game initialization
let game = new Minesweeper();

function createBoard() {
  const board = document.getElementById('board');
  board.innerHTML = '';

  for (let y = 0; y < game.height; y++) {
    for (let x = 0; x < game.width; x++) {
      const cell = document.createElement('button');
      cell.className = 'cell';
      cell.dataset.x = x;
      cell.dataset.y = y;
      board.appendChild(cell);
    }
  }
}

function updateBoard() {
  const cells = document.querySelectorAll('.cell');
  cells.forEach(cell => {
    const x = parseInt(cell.dataset.x);
    const y = parseInt(cell.dataset.y);
    const cellData = game.board[y][x];

    cell.className = 'cell';
    if (cellData.revealed) {
      cell.classList.add('revealed');
      if (cellData.isMine) {
        cell.classList.add('mine');
        cell.textContent = '☣️';
      } else if (cellData.neighborMines > 0) {
        cell.textContent = cellData.neighborMines;
        cell.dataset.number = cellData.neighborMines;
      }
    } else if (cellData.flagged) {
      cell.textContent = '🌱';
    } else {
      cell.textContent = '';
    }
  });
}

function handleClick(e) {
  if (!e.target.matches('.cell')) return;
  
  const x = parseInt(e.target.dataset.x);
  const y = parseInt(e.target.dataset.y);

  if (e.button === 2 || e.ctrlKey) {
    game.toggleFlag(x, y);
  } else {
    const result = game.reveal(x, y);
    if (result === false) {
      setTimeout(() => alert('Game Over!'), 100);
    } else if (result === true) {
      setTimeout(() => alert('You Win!'), 100);
    }
  }
  
  updateBoard();
}

function initGame() {
  game = new Minesweeper();
  createBoard();
  updateBoard();
}

// Event Listeners
document.getElementById('board').addEventListener('click', handleClick);
document.getElementById('board').addEventListener('contextmenu', (e) => {
  e.preventDefault();
  handleClick(e);
});
document.getElementById('new-game').addEventListener('click', initGame);

// Initialize the game
initGame();